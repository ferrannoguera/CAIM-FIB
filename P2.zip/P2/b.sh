python CountWords.py --index testsinfilter1
python CountWords.py --index testlowercase1
python CountWords.py --index testascii1
python CountWords.py --index teststop1
python CountWords.py --index testsnowball1
python CountWords.py --index testporterstem1
python CountWords.py --index testkstem1



python CountWords.py --index testsinfilter2
python CountWords.py --index testlowercase2
python CountWords.py --index testascii2
python CountWords.py --index teststop2
python CountWords.py --index testsnowball2
python CountWords.py --index testporterstem2
python CountWords.py --index testkstem2

python CountWords.py --index testsinfilter3
python CountWords.py --index testlowercase3
python CountWords.py --index testascii3
python CountWords.py --index teststop3
python CountWords.py --index testsnowball3
python CountWords.py --index testporterstem3
python CountWords.py --index testkstem3

python CountWords.py --index testsinfilter4
python CountWords.py --index testlowercase4
python CountWords.py --index testascii4
python CountWords.py --index teststop4
python CountWords.py --index testsnowball4
python CountWords.py --index testporterstem4
python CountWords.py --index testkstem4


