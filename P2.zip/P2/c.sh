python TFIDFViewer.py --index testsinfilter1 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test5.txt 
python TFIDFViewer.py --index testlowercase1 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test5.txt 
python TFIDFViewer.py --index testascii1 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test5.txt 
python TFIDFViewer.py --index teststop1 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test5.txt 
python TFIDFViewer.py --index testsnowball1 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test5.txt 
python TFIDFViewer.py --index testporterstem1 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test5.txt 
python TFIDFViewer.py --index testkstem1 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test5.txt 

python TFIDFViewer.py --index testsinfilter1 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test2.txt 
python TFIDFViewer.py --index testlowercase1 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test2.txt 
python TFIDFViewer.py --index testascii1 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test2.txt 
python TFIDFViewer.py --index teststop1 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test2.txt 
python TFIDFViewer.py --index testsnowball1 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test2.txt 
python TFIDFViewer.py --index testporterstem1 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test2.txt 
python TFIDFViewer.py --index testkstem1 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test2.txt 

python TFIDFViewer.py --index testsinfilter1 --files /tmp/novels/OurTesting/Test5.txt /tmp/novels/OurTesting/Test6.txt 
python TFIDFViewer.py --index testlowercase1 --files /tmp/novels/OurTesting/Test5.txt /tmp/novels/OurTesting/Test6.txt 
python TFIDFViewer.py --index testascii1 --files /tmp/novels/OurTesting/Test5.txt /tmp/novels/OurTesting/Test6.txt 
python TFIDFViewer.py --index teststop1 --files /tmp/novels/OurTesting/Test5.txt /tmp/novels/OurTesting/Test6.txt 
python TFIDFViewer.py --index testsnowball1 --files /tmp/novels/OurTesting/Test5.txt /tmp/novels/OurTesting/Test6.txt 
python TFIDFViewer.py --index testporterstem1 --files /tmp/novels/OurTesting/Test5.txt /tmp/novels/OurTesting/Test6.txt 
python TFIDFViewer.py --index testkstem1 --files /tmp/novels/OurTesting/Test5.txt /tmp/novels/OurTesting/Test6.txt 

python TFIDFViewer.py --index testsinfilter1 --files /tmp/novels/PoeWorksVol1.txt  /tmp/novels/PoeWorksVol2.txt
python TFIDFViewer.py --index testlowercase1 --files /tmp/novels/PoeWorksVol1.txt  /tmp/novels/PoeWorksVol2.txt
python TFIDFViewer.py --index testascii1 --files /tmp/novels/PoeWorksVol1.txt  /tmp/novels/PoeWorksVol2.txt
python TFIDFViewer.py --index teststop1 --files /tmp/novels/PoeWorksVol1.txt  /tmp/novels/PoeWorksVol2.txt
python TFIDFViewer.py --index testsnowball1 --files /tmp/novels/PoeWorksVol1.txt  /tmp/novels/PoeWorksVol2.txt
python TFIDFViewer.py --index testporterstem1 --files /tmp/novels/PoeWorksVol1.txt  /tmp/novels/PoeWorksVol2.txt
python TFIDFViewer.py --index testkstem1 --files /tmp/novels/PoeWorksVol1.txt  /tmp/novels/PoeWorksVol2.txt



python TFIDFViewer.py --index testsinfilter2 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test2.txt 
python TFIDFViewer.py --index testlowercase2 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test2.txt 
python TFIDFViewer.py --index testascii2 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test2.txt 
python TFIDFViewer.py --index teststop2 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test2.txt 
python TFIDFViewer.py --index testsnowball2 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test2.txt 
python TFIDFViewer.py --index testporterstem2 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test2.txt 
python TFIDFViewer.py --index testkstem2 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test2.txt 

python TFIDFViewer.py --index testsinfilter2 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test5.txt 
python TFIDFViewer.py --index testlowercase2 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test5.txt 
python TFIDFViewer.py --index testascii2 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test5.txt 
python TFIDFViewer.py --index teststop2 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test5.txt 
python TFIDFViewer.py --index testsnowball2 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test5.txt 
python TFIDFViewer.py --index testporterstem2 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test5.txt 
python TFIDFViewer.py --index testkstem2 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test5.txt 

python TFIDFViewer.py --index testsinfilter2 --files /tmp/novels/OurTesting/Test6.txt /tmp/novels/OurTesting/Test5.txt 
python TFIDFViewer.py --index testlowercase2 --files /tmp/novels/OurTesting/Test6.txt /tmp/novels/OurTesting/Test5.txt 
python TFIDFViewer.py --index testascii2 --files /tmp/novels/OurTesting/Test6.txt /tmp/novels/OurTesting/Test5.txt 
python TFIDFViewer.py --index teststop2 --files /tmp/novels/OurTesting/Test6.txt /tmp/novels/OurTesting/Test5.txt 
python TFIDFViewer.py --index testsnowball2 --files /tmp/novels/OurTesting/Test6.txt /tmp/novels/OurTesting/Test5.txt 
python TFIDFViewer.py --index testporterstem2 --files /tmp/novels/OurTesting/Test6.txt /tmp/novels/OurTesting/Test5.txt 
python TFIDFViewer.py --index testkstem2 --files /tmp/novels/OurTesting/Test6.txt /tmp/novels/OurTesting/Test5.txt 

python TFIDFViewer.py --index testsinfilter2 --files /tmp/novels/PoeWorksVol1.txt  /tmp/novels/PoeWorksVol2.txt
python TFIDFViewer.py --index testlowercase2 --files /tmp/novels/PoeWorksVol1.txt  /tmp/novels/PoeWorksVol2.txt
python TFIDFViewer.py --index testascii2 --files /tmp/novels/PoeWorksVol1.txt  /tmp/novels/PoeWorksVol2.txt
python TFIDFViewer.py --index teststop2 --files /tmp/novels/PoeWorksVol1.txt  /tmp/novels/PoeWorksVol2.txt
python TFIDFViewer.py --index testsnowball2 --files /tmp/novels/PoeWorksVol1.txt  /tmp/novels/PoeWorksVol2.txt 
python TFIDFViewer.py --index testporterstem2 --files /tmp/novels/PoeWorksVol1.txt  /tmp/novels/PoeWorksVol2.txt 
python TFIDFViewer.py --index testkstem2 --files /tmp/novels/PoeWorksVol1.txt  /tmp/novels/PoeWorksVol2.txt




python TFIDFViewer.py --index testsinfilter3 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test5.txt 
python TFIDFViewer.py --index testlowercase3 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test5.txt 
python TFIDFViewer.py --index testascii3 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test5.txt 
python TFIDFViewer.py --index teststop3 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test5.txt 
python TFIDFViewer.py --index testsnowball3 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test5.txt 
python TFIDFViewer.py --index testporterstem3 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test5.txt 
python TFIDFViewer.py --index testkstem3 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test5.txt 

python TFIDFViewer.py --index testsinfilter3 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test2.txt 
python TFIDFViewer.py --index testlowercase3 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test2.txt 
python TFIDFViewer.py --index testascii3 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test2.txt 
python TFIDFViewer.py --index teststop3 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test2.txt 
python TFIDFViewer.py --index testsnowball3 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test2.txt 
python TFIDFViewer.py --index testporterstem3 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test2.txt 
python TFIDFViewer.py --index testkstem3 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test2.txt 

python TFIDFViewer.py --index testsinfilter3 --files /tmp/novels/OurTesting/Test6.txt /tmp/novels/OurTesting/Test5.txt 
python TFIDFViewer.py --index testlowercase3 --files /tmp/novels/OurTesting/Test6.txt /tmp/novels/OurTesting/Test5.txt 
python TFIDFViewer.py --index testascii3 --files /tmp/novels/OurTesting/Test6.txt /tmp/novels/OurTesting/Test5.txt 
python TFIDFViewer.py --index teststop3 --files /tmp/novels/OurTesting/Test6.txt /tmp/novels/OurTesting/Test5.txt 
python TFIDFViewer.py --index testsnowball3 --files /tmp/novels/OurTesting/Test6.txt /tmp/novels/OurTesting/Test5.txt 
python TFIDFViewer.py --index testporterstem3 --files /tmp/novels/OurTesting/Test6.txt /tmp/novels/OurTesting/Test5.txt 
python TFIDFViewer.py --index testkstem3 --files /tmp/novels/OurTesting/Test6.txt /tmp/novels/OurTesting/Test5.txt 

python TFIDFViewer.py --index testsinfilter3 --files /tmp/novels/PoeWorksVol1.txt  /tmp/novels/PoeWorksVol2.txt
python TFIDFViewer.py --index testlowercase3 --files /tmp/novels/PoeWorksVol1.txt  /tmp/novels/PoeWorksVol2.txt
python TFIDFViewer.py --index testascii3 --files /tmp/novels/PoeWorksVol1.txt  /tmp/novels/PoeWorksVol2.txt
python TFIDFViewer.py --index teststop3 --files /tmp/novels/PoeWorksVol1.txt  /tmp/novels/PoeWorksVol2.txt
python TFIDFViewer.py --index testsnowball3 --files /tmp/novels/PoeWorksVol1.txt  /tmp/novels/PoeWorksVol2.txt
python TFIDFViewer.py --index testporterstem3 --files /tmp/novels/PoeWorksVol1.txt  /tmp/novels/PoeWorksVol2.txt
python TFIDFViewer.py --index testkstem3 --files /tmp/novels/PoeWorksVol1.txt  /tmp/novels/PoeWorksVol2.txt




python TFIDFViewer.py --index testsinfilter4 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test2.txt 
python TFIDFViewer.py --index testlowercase4 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test2.txt 
python TFIDFViewer.py --index testascii4 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test2.txt 
python TFIDFViewer.py --index teststop4 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test2.txt 
python TFIDFViewer.py --index testsnowball4 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test2.txt 
python TFIDFViewer.py --index testporterstem4 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test2.txt 
python TFIDFViewer.py --index testkstem4 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test2.txt 

python TFIDFViewer.py --index testsinfilter4 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test5.txt 
python TFIDFViewer.py --index testlowercase4 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test5.txt 
python TFIDFViewer.py --index testascii4 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test5.txt 
python TFIDFViewer.py --index teststop4 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test5.txt 
python TFIDFViewer.py --index testsnowball4 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test5.txt 
python TFIDFViewer.py --index testporterstem4 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test5.txt 
python TFIDFViewer.py --index testkstem4 --files /tmp/novels/OurTesting/Test1.txt /tmp/novels/OurTesting/Test5.txt 

python TFIDFViewer.py --index testsinfilter4 --files /tmp/novels/OurTesting/Test5.txt /tmp/novels/OurTesting/Test6.txt 
python TFIDFViewer.py --index testlowercase4 --files /tmp/novels/OurTesting/Test5.txt /tmp/novels/OurTesting/Test6.txt 
python TFIDFViewer.py --index testascii4 --files /tmp/novels/OurTesting/Test5.txt /tmp/novels/OurTesting/Test6.txt 
python TFIDFViewer.py --index teststop4 --files /tmp/novels/OurTesting/Test5.txt /tmp/novels/OurTesting/Test6.txt 
python TFIDFViewer.py --index testsnowball4 --files /tmp/novels/OurTesting/Test5.txt /tmp/novels/OurTesting/Test6.txt 
python TFIDFViewer.py --index testporterstem4 --files /tmp/novels/OurTesting/Test5.txt /tmp/novels/OurTesting/Test6.txt 
python TFIDFViewer.py --index testkstem4 --files /tmp/novels/OurTesting/Test5.txt /tmp/novels/OurTesting/Test6.txt 

python TFIDFViewer.py --index testsinfilter4 --files /tmp/novels/PoeWorksVol1.txt  /tmp/novels/PoeWorksVol2.txt
python TFIDFViewer.py --index testlowercase4 --files /tmp/novels/PoeWorksVol1.txt  /tmp/novels/PoeWorksVol2.txt
python TFIDFViewer.py --index testascii4 --files /tmp/novels/PoeWorksVol1.txt  /tmp/novels/PoeWorksVol2.txt 
python TFIDFViewer.py --index teststop4 --files  /tmp/novels/PoeWorksVol1.txt  /tmp/novels/PoeWorksVol2.txt
python TFIDFViewer.py --index testsnowball4 --files  /tmp/novels/PoeWorksVol1.txt  /tmp/novels/PoeWorksVol2.txt
python TFIDFViewer.py --index testporterstem4 --files  /tmp/novels/PoeWorksVol1.txt  /tmp/novels/PoeWorksVol2.txt
python TFIDFViewer.py --index testkstem4 --files  /tmp/novels/PoeWorksVol1.txt  /tmp/novels/PoeWorksVol2.txt
