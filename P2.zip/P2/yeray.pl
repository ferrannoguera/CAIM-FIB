Comparaciones que hacer:


(Tus testos)

Novels: 

PoeWorksVol1 -> PoeWorksVol2
 
(prueva mierdas que tengan logica)
